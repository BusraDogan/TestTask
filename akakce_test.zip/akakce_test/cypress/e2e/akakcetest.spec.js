describe('Cypress Test', () => {
    it('Visits the Akakce Site', () => {
        // Go to Akakce website
        cy.visit('https://www.akakce.com/')

        // Find search box
         cy.get('input[id="q"]')  // find search box
            .type('Iphone', { delay: 30 }) // 30 ms delay
            cy.wait(2000);

        // Click search box  field
         cy.get('button[title="Ara"]').click();  //  click search button


         // Click first item on list
         cy.get('span.bt_v8').first().click();

         // Click Takip Et button on the product
         cy.contains('span.ufo_v8', 'Takip Et').click();

       
    })
})
